@extends('layouts.front_layout.front_layout')
@section('content')

<div class="page2">
    <div class="upcomingshows">
      <h1>UPCOMING SHOWS</h1>
      @foreach($getLatestEvents as $events)
      <div class="solidLine"></div>
      <div class="tour-list1">
        <div class="box">{{ $events['date'] }}</div>
        <div class="box">{{ $events['country'] }}</div>
        <div class="box">{{ $events['place'] }}</div>
      </div>
      @endforeach
    </div>
    <div class="solidLine"></div>
    <h2>INSTAGRAM-FEED</h2>
    <div class="instacontainer">
      <div class="instafeed">
        <div class="embedsocial-hashtag" data-ref="eca04559c6d653f7c67906120ac66c4311bcbb39"> <a
            class="feed-powered-by-es feed-powered-by-es-feed-new"
            href="https://embedsocial.com/social-media-aggregator/" target="_blank" title="Widget by EmbedSocial">
            Widget by EmbedSocial<span>→</span> </a> </div>
      </div>
    </div>
  </div>

@endsection