<header>
    <nav class="navbar">
      <a href="#" class="nav-logo"></a>
      <ul class="nav-menu">
        <li class="nav-item">
          <a href="#" class="nav-link">BIO</a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">NEWS</a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">CONTACT</a>
        </li>
      </ul>
      <div class="hamburger">
        <span class="bar"></span>
        <span class="bar"></span>
        <span class="bar"></span>
      </div>
    </nav>
  </header>
  <div class="page1">
    <img src="{{asset ('images/TCI-test1.jpg')}}" alt="En bild" class="band-bild">
    <a href="index.html"><img src="{{asset ('images/TCI-Logo-White.png')}}" alt="logo" class="logo"></a>
    <a href="#" class="bio-link">BIO</a>
    <a href="#" class="news-link">NEWS</a>
    <a href="#" class="contact-link">CONTACT</a>
    <a href="https://www.facebook.com/thecruelintentions" target="blank"> <i class="fa-brands fa-facebook"></i></a>
    <a href="https://www.instagram.com/thecruelintentionsofficial/" target="blank"><i
        class="fa-brands fa-instagram"></i></a>
    <a href="https://open.spotify.com/artist/3RKn3P56kkewba1s6QpyDk?si=qZaY6wQhRMSSgX DG_Zmh4Q" target="blank"><i
        class="fa-brands fa-spotify"></i></a>
    <a href="https://www.youtube.com/@TheCruelIntentions" target="blank"><i class="fa-brands fa-youtube"></i></a>
    <a href="https://shop.merchants.se/cruel-intentions-the/" target="blank"><button class="merchKnapp"><i
          class="fa-solid fa-cart-shopping"></i>SHOP MERCH</button></a>
  </div>