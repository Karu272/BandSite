<footer>
    <div class="footContainer">
        <h1>Here will be a footer</h1>
    </div>
</footer>