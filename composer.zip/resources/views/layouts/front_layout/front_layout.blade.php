<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/b40f80a2a6.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="{{url('css/front/style.css')}}">
  <title>ProjektX</title>
</head>

<body>
    <!--Header===================================================-->
    @include('layouts.front_layout.front_header')
    <!--/Header===================================================-->
    <!--Mid part===================================================-->
    @yield('content')
    <!--/Mid part===================================================-->
    <!--Footer=============================================-->
    @include('layouts.front_layout.front_footer')
    <!--/Footer=============================================-->

    <script src="{{url('js/front/script.js')}}"></script>
</body>

</html>
