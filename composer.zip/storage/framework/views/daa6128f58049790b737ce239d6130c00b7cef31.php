
<?php $__env->startSection('content'); ?>

    <div class="mid-box">
        <h2>Admin</h2>
        <h3>Panel</h3>
    </div>
    <div class="dashboard-box">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <button class="pimp-btn2"><a href="<?php echo e(url('admin/eventPage')); ?>"><i>Edit EVENT</i></a></button>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Band\resources\views/admin/admin_dashboard.blade.php ENDPATH**/ ?>