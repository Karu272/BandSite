<footer>
    <div class="footContainer">
        <h1>Here will be a footer</h1>
    </div>
</footer><?php /**PATH C:\Projects\Band\resources\views/layouts/front_layout/front_footer.blade.php ENDPATH**/ ?>