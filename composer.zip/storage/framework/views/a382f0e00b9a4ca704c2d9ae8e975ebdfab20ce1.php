
<?php $__env->startSection('content'); ?>

<div class="page2">
    <div class="upcomingshows">
      <h1>UPCOMING SHOWS</h1>
      <?php $__currentLoopData = $getLatestEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $events): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="solidLine"></div>
      <div class="tour-list1">
        <div class="box"><?php echo e($events['date']); ?></div>
        <div class="box"><?php echo e($events['country']); ?></div>
        <div class="box"><?php echo e($events['place']); ?></div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="solidLine"></div>
    <h2>INSTAGRAM-FEED</h2>
    <div class="instacontainer">
      <div class="instafeed">
        <div class="embedsocial-hashtag" data-ref="eca04559c6d653f7c67906120ac66c4311bcbb39"> <a
            class="feed-powered-by-es feed-powered-by-es-feed-new"
            href="https://embedsocial.com/social-media-aggregator/" target="_blank" title="Widget by EmbedSocial">
            Widget by EmbedSocial<span>→</span> </a> </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_layout.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Band\resources\views/front/index.blade.php ENDPATH**/ ?>