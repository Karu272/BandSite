<footer>
    <div class="footer-box">
        <div class="container">
            <p>&copy 2023 Karu. All rights reserved </a></p>
        </div>
    </div>
</footer><?php /**PATH C:\Projects\Band\resources\views/layouts/admin_layout/admin_footer.blade.php ENDPATH**/ ?>