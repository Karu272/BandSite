<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://kit.fontawesome.com/b40f80a2a6.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/front/style.css')); ?>">
  <title>ProjektX</title>
</head>

<body>
    <!--Header===================================================-->
    <?php echo $__env->make('layouts.front_layout.front_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--/Header===================================================-->
    <!--Mid part===================================================-->
    <?php echo $__env->yieldContent('content'); ?>
    <!--/Mid part===================================================-->
    <!--Footer=============================================-->
    <?php echo $__env->make('layouts.front_layout.front_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--/Footer=============================================-->

    <script src="<?php echo e(url('js/front/script.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Projects\Band\resources\views/layouts/front_layout/front_layout.blade.php ENDPATH**/ ?>