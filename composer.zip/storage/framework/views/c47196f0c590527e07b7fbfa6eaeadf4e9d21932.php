<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge,chrome=1">
    <link rel="stylesheet" href="<?php echo e(Url('css/admin/login.css')); ?>">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates&display=swap" rel="stylesheet">
    <title>Admin Login</title>
</head>

<body>
    <div class="container">
        <?php if(Session::has('error_message')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(URL('/admin')); ?>" method="post"><?php echo csrf_field(); ?>
            <div class="box1">
                <h3>Admin Login</h3>
            </div>
            <br>
            <div class="box2">
                <label for="title">E-mail</label>
            </div>
            <div class="box3">
                <input class="email" type="email" name="email" id="email" placeholder="E-mail">
            </div>
            <div class="box4">
                <label for="title2">Password</label>
            </div>
            <div class="box5">
                <input class="password" type="password" name="password" id="password" placeholder="Password">
            </div>
            <div class="box6">
                <button class="btn" type="submit">Login</button>
            </div>
        </form>
    </div>
</body>

</html>
<?php /**PATH C:\Projects\Band\resources\views/admin/admin_login.blade.php ENDPATH**/ ?>