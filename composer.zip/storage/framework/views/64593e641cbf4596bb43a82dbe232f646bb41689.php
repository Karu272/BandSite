
<?php $__env->startSection('content'); ?>
    <div class="container-settings">
        <div class="tablecontainer">
            <!-- Success MSG start -->
            <?php if(Session::has('success_message')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(Session::get('success_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php Session::forget('success_message'); ?>
            <?php endif; ?>
            <?php if(Session::has('error_message')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get('error_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php Session::forget('error_message'); ?>
            <?php endif; ?>
            <!-- Success MSG end -->
            <form name="eventForm" id="EventForm" <?php if(empty($eventData['id'])): ?> action="<?php echo e(url('admin/add-edit-event')); ?>" <?php else: ?> action="<?php echo e(url('admin/add-edit-event/' . $eventData['id'])); ?>" <?php endif; ?> method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                <h3><?php echo e($title); ?></h3>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="country">Date</label>
                                <input type="text" class="form-control" name="date" id="date"
                                    placeholder="date... " <?php if(!empty($eventData['date'])): ?> value="<?php echo e($eventData['date']); ?>" <?php else: ?> value="<?php echo e(old('date')); ?>" <?php endif; ?>>
                            </div>
                            <div class="form-group">
                                <label for="country">Country</label>
                                <textarea name="country" id="country" class="form-control" rows="3"
                                    placeholder="country..."
                                    required><?php if(!empty($eventData['country'])): ?><?php echo e($eventData['country']); ?><?php else: ?><?php echo e(old('country')); ?><?php endif; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="place">Place</label>
                                <textarea name="place" id="place" class="form-control" rows="3"
                                    placeholder="Event Text..."
                                    required><?php if(!empty($eventData['place'])): ?><?php echo e($eventData['place']); ?><?php else: ?><?php echo e(old('place')); ?><?php endif; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Band\resources\views/admin/edit/add_edit_event.blade.php ENDPATH**/ ?>